
CREATE PROCEDURE JohnMorrisseySkillInsert
	
		@SkillName varchar(35),
		@SkillDescription varchar(90),
		@LastUpdatedBy varchar(50),
		@LastUpdated date

	AS

	Set NOCOUNT ON 

	INSERT INTO [dbo].[Skill]
		([SkillName]
		,[SkillDescription]
		,[LastUpdatedBy]
		,[LastUpdated])
	VALUES
		(@SkillName
		,@SkillDescription
		,@LastUpdatedBy
		,@LastUpdated)
GO
